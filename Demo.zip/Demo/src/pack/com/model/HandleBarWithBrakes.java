package pack.com.model;

public class HandleBarWithBrakes {

	private String handle;
	private int noOfGears;

	public String getHandle() {
		return handle;
	}

	public void setHandle(String handle) {
		this.handle = handle;
	}

	public int getNoOfGears() {
		return noOfGears;
	}

	public void setNoOfGears(int noOfGears) {
		this.noOfGears = noOfGears;
	}

	public HandleBarWithBrakes(String handle, int noOfGears) {
		super();
		this.handle = handle;
		this.noOfGears = noOfGears;
	}

	public HandleBarWithBrakes(int noOfGears) {
		super();
		this.noOfGears = noOfGears;
	}
	
	

}
