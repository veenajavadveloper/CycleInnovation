package pack.com.model;

public class Cycle {

	private ChainAssembly assembly;
	private Frame frame;
	private HandleBarWithBrakes barWithBrakes;
	private Seatings seatings;
	private Wheels wheels;

	public Cycle(ChainAssembly assembly, Frame frame, HandleBarWithBrakes barWithBrakes, Seatings seatings,
			Wheels wheels) {
		super();
		this.assembly = assembly;
		this.frame = frame;
		this.barWithBrakes = barWithBrakes;
		this.seatings = seatings;
		this.wheels = wheels;
	}

	public ChainAssembly getAssembly() {
		return assembly;
	}

	public void setAssembly(ChainAssembly assembly) {
		this.assembly = assembly;
	}

	public Frame getFrame() {
		return frame;
	}

	public void setFrame(Frame frame) {
		this.frame = frame;
	}

	public HandleBarWithBrakes getBarWithBrakes() {
		return barWithBrakes;
	}

	public void setBarWithBrakes(HandleBarWithBrakes barWithBrakes) {
		this.barWithBrakes = barWithBrakes;
	}

	public Seatings getSeatings() {
		return seatings;
	}

	public void setSeatings(Seatings seatings) {
		this.seatings = seatings;
	}

	public Wheels getWheels() {
		return wheels;
	}

	public void setWheels(Wheels wheels) {
		this.wheels = wheels;
	}
	
	public Cycle() {
		// TODO Auto-generated constructor stub
	}

}
