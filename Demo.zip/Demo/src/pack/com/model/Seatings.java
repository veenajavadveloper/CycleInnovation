package pack.com.model;

public class Seatings {
	private String cusionType;
	private String spring;

	public Seatings() {
		// TODO Auto-generated constructor stub
	}

	public Seatings(String cusionType, String spring) {
		super();
		this.cusionType = cusionType;
		this.spring = spring;
	}


	public Seatings(String cusionType) {
		super();
		this.cusionType = cusionType;
		this.spring = "normal";
	}
	
	public String getCusionType() {
		return cusionType;
	}

	public void setCusionType(String cusionType) {
		this.cusionType = cusionType;
	}

	public String getSpring() {
		return spring;
	}

	public void setSpring(String spring) {
		this.spring = spring;
	}

	@Override
	public String toString() {
		return cusionType;
	}
}
