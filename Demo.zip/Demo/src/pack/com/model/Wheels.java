package pack.com.model;

public class Wheels {

	int spokes;
	String rim;
	String tubeType;
	String tyre;

	public Wheels(int spokes, String rim, String tubeType, String tyre) {
		super();
		this.spokes = spokes;
		this.rim = rim;
		this.tubeType = tubeType;
		this.tyre = tyre;
	}

	public Wheels(String tubeType) {
		super();
		this.tubeType = tubeType;
	}

	public int getSpokes() {
		return spokes;
	}

	public void setSpokes(int spokes) {
		this.spokes = spokes;
	}

	public String getRim() {
		return rim;
	}

	public void setRim(String rim) {
		this.rim = rim;
	}

	public String getTubeType() {
		return tubeType;
	}

	public void setTubeType(String tubeType) {
		this.tubeType = tubeType;
	}

	public String getTyre() {
		return tyre;
	}

	public void setTyre(String tyre) {
		this.tyre = tyre;
	}

}