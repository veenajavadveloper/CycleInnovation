package pack.com.model;

public class Frame {
	private String topHead;
	private String headTube;
	private String downTube;
	private String bottomBracketShell;
	private String seatStays;
	private String chainStays;

	private String metalType;

	public Frame() {
		// TODO Auto-generated constructor stub
	}

	public Frame(String metalType) {
		super();
		this.metalType = metalType;
	}

	public Frame(String topHead, String headTube, String downTube, String bottomBracketShell, String seatStays,
			String chainStays, String metalType) {
		super();
		this.topHead = topHead;
		this.headTube = headTube;
		this.downTube = downTube;
		this.bottomBracketShell = bottomBracketShell;
		this.seatStays = seatStays;
		this.chainStays = chainStays;
		this.metalType = metalType;
	}

	public String getTopHead() {
		return topHead;
	}

	public void setTopHead(String topHead) {
		this.topHead = topHead;
	}

	public String getHeadTube() {
		return headTube;
	}

	public void setHeadTube(String headTube) {
		this.headTube = headTube;
	}

	public String getDownTube() {
		return downTube;
	}

	public void setDownTube(String downTube) {
		this.downTube = downTube;
	}

	public String getBottomBracketShell() {
		return bottomBracketShell;
	}

	public void setBottomBracketShell(String bottomBracketShell) {
		this.bottomBracketShell = bottomBracketShell;
	}

	public String getSeatStays() {
		return seatStays;
	}

	public void setSeatStays(String seatStays) {
		this.seatStays = seatStays;
	}

	public String getChainStays() {
		return chainStays;
	}

	public void setChainStays(String chainStays) {
		this.chainStays = chainStays;
	}

	public String getMetalType() {
		return metalType;
	}

	public void setMetalType(String metalType) {
		this.metalType = metalType;
	}

	@Override
	public String toString() {
		return metalType;
	}
}
