package pack.com.model;

public class ChainAssembly {
	 private String chainType;

	public ChainAssembly(String chainType) {
		super();
		this.chainType = chainType;
	}

	public String getChainType() {
		return chainType;
	}

	public void setChainType(String chainType) {
		this.chainType = chainType;
	}

	@Override
	public String toString() {
		return chainType;
	}
	 
	
	 
}
