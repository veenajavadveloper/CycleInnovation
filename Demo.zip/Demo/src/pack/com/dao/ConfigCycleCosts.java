package pack.com.dao;

import java.util.Random;

import pack.com.model.ChainAssembly;
import pack.com.model.Frame;
import pack.com.model.HandleBarWithBrakes;
import pack.com.model.Wheels;

public class ConfigCycleCosts implements Runnable {

	@Override
	public void run() {
		Frame frame = new Frame("Aluminium");
		Wheels wheels = new Wheels("Tubeless");
		ChainAssembly assembly = new ChainAssembly("LongChain");
		Random random = new Random();
		int max = 5;
		int min = 0;
		HandleBarWithBrakes brakes = new HandleBarWithBrakes(random.nextInt(max - min + 1) + min);
		System.out.println("The cost of cycle is: "+CycleCostCalc.calculatePrice(frame, wheels, assembly, brakes));
	}

}
