package pack.com.dao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Demo {
public static void main(String[] args) {
	ExecutorService service=Executors.newFixedThreadPool(10);
	ConfigCycleCosts task=new ConfigCycleCosts();
	for (int i = 1; i <=1000; i++) {
		service.submit(task);
	}
	service.shutdown();
}
}
