package pack.com.dao;

import pack.com.model.ChainAssembly;
import pack.com.model.Cycle;
import pack.com.model.Frame;
import pack.com.model.HandleBarWithBrakes;
import pack.com.model.Seatings;
import pack.com.model.Wheels;

public class CycleCostCalc {

	public static int calculatePrice(Frame frame, Wheels wheels, ChainAssembly assembly, HandleBarWithBrakes brakes) {
		int total = 0;

		if (frame.toString().equals("Aluminium")) {
			total = total + 20;
		} else if (frame.toString().equals("Steel")) {
			total = total + 25;
		}

		if (assembly.getChainType().equals("LongChain")) {
			total = total + 10;
		} else {
			total = total + 5;
		}

		if (wheels.getTubeType().equals("Tubeless")) {
			total = total + 20;
		} else {
			total = total + 10;
		}

		if (brakes.getNoOfGears() != 0) {
			total = total + brakes.getNoOfGears() * 20;
		} else {
			total = total + 20;
		}
		return total;
	}
}
